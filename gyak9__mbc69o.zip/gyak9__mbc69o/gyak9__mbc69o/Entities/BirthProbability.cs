﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gyak9__mbc69o.Entities
{
    public class BirthProbability
    {
        public int Age { get; set; }
        public int NumberofChildren { get; set; }
        public double Probability { get; set; }
    }
}
